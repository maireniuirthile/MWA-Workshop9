var albumsApp = angular.module('albumsApp', [])

albumsApp.factory('albumsFactory', function($http) {
    return {
        //getAlbums: function() {
        //  return[{"artist": "Kid 606",  "title": "Happiness"},  {"artist": "Yuck","title": "Glow and Behold" }];
        getalbumsAsync: function(callback) {
            $http.get('albums.json').success(callback);
        }
    };
});

albumsApp.controller('albumController', function($scope, albumsFactory) {
  //  $scope.albums = albumsFactory.getAlbums();
    albumsFactory.getalbumsAsync(function(results) {
        console.log('albumController async returned value');
        $scope.albums = results.albums;
        $scope.sort = "artist";
        $scope.setSort= function(type){$scope.sort = type};
    });    
});




    
